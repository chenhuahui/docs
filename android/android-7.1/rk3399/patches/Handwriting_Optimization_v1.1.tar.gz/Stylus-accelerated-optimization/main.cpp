/*************************************************
 * Copyright (C) 2018 Fuzhou Rockchip Electronics Co.Ltd.
 *
 * Modification based on code covered by the Apache License, Version 2.0 (the "License").
 * You may not use this software except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS TO YOU ON AN "AS IS" BASIS
 * AND ANY AND ALL WARRANTIES AND REPRESENTATIONS WITH RESPECT TO SUCH SOFTWARE, WHETHER EXPRESS,
 * IMPLIED, STATUTORY OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY IMPLIED WARRANTIES OF TITLE,
 * NON-INFRINGEMENT, MERCHANTABILITY, SATISFACTROY QUALITY, ACCURACY OR FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.
 *
 * Author:
 *        libin <bin.li@rock-chips.com>
 * Date:
 *        2020-01-09
 * Description:
 *        Output display content by calling libdrm interface.
 *
 **************************************************/
#include <assert.h>
#include <errno.h>
#include <getopt.h>
#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cutils/properties.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>     /* System V */
#include <sys/ioctl.h>  /* BSD and Linux */

#include <xf86drm.h>
#include <xf86drmMode.h>
#include <pthread.h>

#include "display/vop_buffers.h"
#include "display/vop_args.h"
#include "display/vop_set.h"
#include "display/vop_info.h"
#include "display/util/common.h"
#include "display/util/format.h"
#include "render/RenderInputEvent.h"
#include "render/RenderThread.h"

using namespace android;

#define SCREEN_WIDTH 1536
#define SCREEN_HEIGHT  2048

int main(){

  struct win_arg win_args;
  struct bo *win_bo = NULL;
  struct file_arg file_args;
  uint32_t fb_id;
  int ret = 0;
  memset(&win_args, 0, sizeof(win_args));
  memset(&file_args, 0, sizeof(file_args));

  /* Configuration win information */
  {
    win_args.win_type = DRM_PLANE_TYPE_OVERLAY | DRM_PLANE_PERFORMANCE;  //win1-0
    win_args.crtc_id = 0;   //set none

   /*
    *   DRM_MODE_CONNECTOR_Unknown      0
    *   DRM_MODE_CONNECTOR_VGA          1
    *   DRM_MODE_CONNECTOR_DVII         2
    *   DRM_MODE_CONNECTOR_DVID         3
    *   DRM_MODE_CONNECTOR_DVIA         4
    *   DRM_MODE_CONNECTOR_Composite    5
    *   DRM_MODE_CONNECTOR_SVIDEO       6
    *   DRM_MODE_CONNECTOR_LVDS         7
    *   DRM_MODE_CONNECTOR_Component    8
    *   DRM_MODE_CONNECTOR_9PinDIN      9
    *   DRM_MODE_CONNECTOR_DisplayPort  10
    *   DRM_MODE_CONNECTOR_HDMIA        11
    *   DRM_MODE_CONNECTOR_HDMIB        12
    *   DRM_MODE_CONNECTOR_TV           13
    *   DRM_MODE_CONNECTOR_eDP          14
    *   DRM_MODE_CONNECTOR_VIRTUAL      15
    *   DRM_MODE_CONNECTOR_DSI          16
    *   DRM_MODE_CONNECTOR_DPI          17
    */
    win_args.connector_type = DRM_MODE_CONNECTOR_eDP;

    //resolution mode
    win_args.mode_w = SCREEN_WIDTH;
    win_args.mode_h = SCREEN_HEIGHT;

    //src crop
    win_args.crop_left = 0;
    win_args.crop_top = 0;
    win_args.crop_w = SCREEN_WIDTH;
    win_args.crop_h = SCREEN_HEIGHT;

    //disp_rec
    win_args.disp_left = 0;
    win_args.disp_top = 0;
    win_args.disp_w = SCREEN_WIDTH;
    win_args.disp_h = SCREEN_HEIGHT;

    //zpos
    win_args.zpos = 3; //Maybe platform don't support zpos = 3, check it!

    //format
    strcpy(win_args.format_str, "AB24");
    //all format in struct format_info
    win_args.fourcc = util_format_fourcc(win_args.format_str);
  }

  // Initial buffer 0
  {
    fb_id = 0;
    file_args.w = SCREEN_WIDTH;
    file_args.h = SCREEN_HEIGHT;
    strcpy(file_args.format_str, "AB24");
    file_args.fourcc = util_format_fourcc(file_args.format_str);
    strcpy(file_args.file_path, ""); //file_path : /data/dmlayer1_800_1280.bin
    initial_win_buffer(&file_args, &fb_id,win_bo);
  }

  // Initial vop
  {
    // Vop init
    ret = vop_init(win_args,fb_id);
    if(ret < 0){
        fprintf(stderr, "Vop init err, stop!\n");
        return -1;
    }else{
        fprintf(stderr, "Vop init success! \n");
    }

    // Vop enable
    ret = vop_set(win_args,fb_id);
    if(ret < 0){
        fprintf(stderr, "Vop set err, stop!\n");
        return -1;
    }else{
        fprintf(stderr, "Vop set success! \n");
    }
  }


  // Initial handwriting render thread
  // Render handwriting
  sp<RenderThread> paintThread = new RenderThread();

  // Set Bitmap address
  paintThread->setDrawMap(file_args.virtual_addr);

  // Set Bitmap size
  paintThread->setDrawSize(file_args.w,file_args.h);

  // Set pencil scaling factor
  paintThread->setScale(0.750,   1.332);

  // Set touch screen scaling factor
  paintThread->setmScale(0.750,  1.332);

  paintThread->render();

  while(true){
    sleep(10);
  }

  // Vop disable
  vop_disable(win_args);

  // Destroy buffer
  bo_destroy(win_bo);

  // Vop uninit
  vop_uninit();

  return ret;
}
