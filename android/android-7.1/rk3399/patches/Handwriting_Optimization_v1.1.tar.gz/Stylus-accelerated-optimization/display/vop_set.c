/*************************************************
 * Copyright (C) 2018 Fuzhou Rockchip Electronics Co.Ltd.
 *
 * Modification based on code covered by the Apache License, Version 2.0 (the "License").
 * You may not use this software except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS TO YOU ON AN "AS IS" BASIS
 * AND ANY AND ALL WARRANTIES AND REPRESENTATIONS WITH RESPECT TO SUCH SOFTWARE, WHETHER EXPRESS,
 * IMPLIED, STATUTORY OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY IMPLIED WARRANTIES OF TITLE,
 * NON-INFRINGEMENT, MERCHANTABILITY, SATISFACTROY QUALITY, ACCURACY OR FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.
 *
 * Author:
 *        libin <bin.li@rock-chips.com>
 * Date:
 *        2020-01-09
 * Description:
 *        Output display content by calling libdrm interface.
 *
 **************************************************/

#include <assert.h>
#include <errno.h>
#include <getopt.h>
#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <cutils/properties.h>
#include <time.h>

#include <sys/mman.h>
#include <drm_fourcc.h>
#include <xf86drm.h>
#include <xf86drmMode.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <unistd.h>     /* System V */
#include <sys/ioctl.h>  /* BSD and Linux */

#include <pthread.h>

#include "display/vop_buffers.h"
#include "display/vop_args.h"
#include "display/vop_set.h"
#include "display/util/common.h"
#include "display/util/format.h"

drmModeResPtr res = NULL;
drmModeConnectorPtr connector = NULL;
drmModeEncoderPtr encoder = NULL;
drmModeCrtcPtr crtc = NULL;
drmModePlaneResPtr plane_res = NULL;
drmModePlanePtr plane = NULL;
drmModeObjectPropertiesPtr props = NULL;
drmModePropertyPtr prop = NULL;

struct plane_prop plane_prop;
int i, fd, ret;
uint32_t found_crtc = 0,found_plane = 0  ,found_conn = 0;

int find_active_crtc(struct win_arg win_args){

  drmModeModeInfo *mode = NULL;

  for (int i = 0; i < res->count_crtcs; ++i) {
    crtc = drmModeGetCrtc(fd, res->crtcs[i]);
    if (!crtc) {
      fprintf(stderr, "Could not get crtc %u: %s\n",res->crtcs[i], strerror(errno));
      continue;
    }

    fprintf(stderr,"<<<<< Want to find active CRTC: crtc_id = %d:\n",crtc->crtc_id);

    props = drmModeObjectGetProperties(fd, crtc->crtc_id,
               DRM_MODE_OBJECT_CRTC);
    if (!props) {
      fprintf(stderr, "Failed to found props crtc[%d] %s\n",crtc->crtc_id, strerror(errno));
      drmModeFreeCrtc(crtc);
      crtc = NULL;
      continue;
    }

    for (uint32_t j = 0; j < props->count_props; j++) {
      prop = drmModeGetProperty(fd, props->props[j]);
      fprintf(stderr,"\t Index = %2u, prop_name = %15s, value = %lu \n", j, prop->name, props->prop_values[j]);
      if (!strcmp(prop->name, "ACTIVE")) {
        if (props->prop_values[j]) {
          found_crtc = i+1;
          /*
           * Found active connect.
           */
          for (i = 0; i < res->count_connectors; ++i) {
            connector = drmModeGetConnector(fd, res->connectors[i]);

            /* connector must be connected */
            if(connector->connection == DRM_MODE_CONNECTED){
              found_conn = 1;
            }else{
              drmModeFreeConnector(connector);
              connector = NULL;
              continue;
            }
            for(int j = 0;;){
              drmModeModeInfo *mode_temp = &(connector->modes[j]);
              if(mode_temp == NULL)
                break;
              if(win_args.mode_w == 0 || win_args.mode_h == 0){
                mode = mode_temp;
                break;
              }
              if(mode_temp->hdisplay == win_args.mode_w && mode_temp->vdisplay == win_args.mode_h){
                mode = mode_temp;
                break;
              }
              j++;
            }
            if(mode == NULL){
              drmModeFreeConnector(connector);
              connector = NULL;
              continue;
            }
            fprintf(stderr,"<<<<< To find connector_id = %u, connection = %d,mode w=%d,h=%d\n",
              connector->connector_id,connector->connection,mode->hdisplay,mode->vdisplay);

            if (found_conn){
              fprintf(stderr, ">>>>> Find active connect_id %d\n", connector->connector_id);
              break;
            }
            drmModeFreeConnector(connector);
            connector = NULL;
            mode = NULL;
          }
        }
      }
      drmModeFreeProperty(prop);

      if(found_crtc){
          fprintf(stderr, ">>>>> Find active crtc %d\n", crtc->crtc_id);
          return 0;
      }
    }
  }
  return -ENODEV;
}

int find_active_crtc_by_connector_type(struct win_arg win_args){

  drmModeModeInfo *mode = NULL;

  for (int i = 0; i < res->count_crtcs; ++i) {
    crtc = drmModeGetCrtc(fd, res->crtcs[i]);
    if (!crtc) {
      fprintf(stderr, "Could not get crtc %u: %s\n",res->crtcs[i], strerror(errno));
      continue;
    }

    fprintf(stderr,"<<<<< Want to find active CRTC: crtc_id = %d:\n",crtc->crtc_id);

    props = drmModeObjectGetProperties(fd, crtc->crtc_id,
               DRM_MODE_OBJECT_CRTC);
    if (!props) {
      fprintf(stderr, "Failed to found props crtc[%d] %s\n",crtc->crtc_id, strerror(errno));
      drmModeFreeCrtc(crtc);
      crtc = NULL;
      continue;
    }

    for (uint32_t j = 0; j < props->count_props; j++) {
      prop = drmModeGetProperty(fd, props->props[j]);
      fprintf(stderr,"\t Index = %2u, prop_name = %15s, value = %lu \n", j, prop->name, props->prop_values[j]);
      if (!strcmp(prop->name, "ACTIVE")) {
        if (props->prop_values[j]) {
          found_crtc = i+1;
          /*
           * Found active connect.
           */
          for (i = 0; i < res->count_connectors; ++i) {
            connector = drmModeGetConnector(fd, res->connectors[i]);

            /* connector must be connected */
            if(connector->connection == DRM_MODE_CONNECTED && win_args.connector_type == connector->connector_type){
              found_conn = 1;
            }else{
              drmModeFreeConnector(connector);
              connector = NULL;
              continue;
            }
            for(int j = 0;;){
              drmModeModeInfo *mode_temp = &(connector->modes[j]);
              if(mode_temp == NULL)
                break;
              if(win_args.mode_w == 0 || win_args.mode_h == 0){
                mode = mode_temp;
                break;
              }
              if(mode_temp->hdisplay == win_args.mode_w && mode_temp->vdisplay == win_args.mode_h){
                mode = mode_temp;
                break;
              }
              j++;
            }
            if(mode == NULL){
              drmModeFreeConnector(connector);
              connector = NULL;
              continue;
            }
            fprintf(stderr,"<<<<< To find connector_id = %u, connection = %d,mode w=%d,h=%d\n",
              connector->connector_id,connector->connection,mode->hdisplay,mode->vdisplay);

            if (found_conn){
              fprintf(stderr, ">>>>> Find active connect_id %d\n", connector->connector_id);
              break;
            }
            drmModeFreeConnector(connector);
            connector = NULL;
            mode = NULL;
          }
        }
      }
      drmModeFreeProperty(prop);

      if(found_crtc){
          fprintf(stderr, ">>>>> Find active crtc %d\n", crtc->crtc_id);
          return 0;
      }
    }
  }
  return -ENODEV;
}

int find_crtc_by_crtc_id(struct win_arg win_args,uint32_t fb_id){

  drmModeModeInfo *mode = NULL;

  for (int i = 0; i < res->count_crtcs; ++i) {
    crtc = drmModeGetCrtc(fd, res->crtcs[i]);
    if (!crtc) {
      fprintf(stderr, "Could not get crtc %u: %s\n",res->crtcs[i], strerror(errno));
      continue;
    }

    fprintf(stderr,"<<<<< Want to find active CRTC: crtc_id = %d:\n",crtc->crtc_id);

    props = drmModeObjectGetProperties(fd, crtc->crtc_id,
               DRM_MODE_OBJECT_CRTC);
    if (!props) {
      fprintf(stderr, "Failed to found props crtc[%d] %s\n",crtc->crtc_id, strerror(errno));
      drmModeFreeCrtc(crtc);
      crtc = NULL;
      continue;
    }

    if(win_args.crtc_id == crtc->crtc_id){
      found_crtc = i+1;
      /*
       * Found active connector.
       */
      fprintf(stderr,"<<<<< To find connector \n");
      for (int i = 0; i < res->count_connectors; ++i) {
        connector = drmModeGetConnector(fd, res->connectors[i]);
        /* connector must be connected */
        if(connector->connection == DRM_MODE_CONNECTED){
          found_conn = 1;
        }else{
          drmModeFreeConnector(connector);
          connector = NULL;
          continue;
        }
        // Find connector mode
        for(int j = 0;;){
          drmModeModeInfo *mode_temp = &(connector->modes[j]);
          if(mode_temp == NULL)
            break;
          if(win_args.mode_w == 0 || win_args.mode_h == 0){
            mode = mode_temp;
            break;
          }
          if(mode_temp->hdisplay == win_args.mode_w && mode_temp->vdisplay == win_args.mode_h){
            mode = mode_temp;
            break;
          }
          j++;
        }
        if(mode == NULL){
          drmModeFreeConnector(connector);
          connector = NULL;
          continue;
        }
        fprintf(stderr,"<<<<< To find connector_id = %u, connection = %d,mode w=%d,h=%d\n",
          connector->connector_id,connector->connection,mode->hdisplay,mode->vdisplay);

        if (found_conn){
          fprintf(stderr, ">>>>> Find active connect_id %d\n", connector->connector_id);
          break;
        }
      }
      if (i == res->count_connectors) {
        fprintf(stderr, "failed to find usable connector\n");
        drmModeFreeProperty(prop);
        drmModeFreeConnector(connector);
        connector = NULL;
        mode = NULL;
        return -ENODEV;
      }
      /* enable crtc and connect */
      ret = drmModeSetCrtc(fd, crtc->crtc_id, fb_id, 0, 0, &(connector->connector_id), 1, mode);
      if (ret) {
        fprintf(stderr, "drmModeSetCrtc faild:%d\n", ret);
        drmModeFreeProperty(prop);
        drmModeFreeConnector(connector);
        connector = NULL;
        mode = NULL;
        return -ENODEV;
      }
    }

    if(found_crtc){
        fprintf(stderr, ">>>>> Find active crtc %d\n", crtc->crtc_id);
        return 0;
    }

  }
  return -ENODEV;
}

int find_crtc_by_connector_type(struct win_arg win_args,uint32_t fb_id){

  drmModeModeInfo *mode;
  /*
   * Found connected connect.
   */
  for (int i = 0; i < res->count_connectors; ++i) {
    connector = drmModeGetConnector(fd, res->connectors[i]);

    if(win_args.connector_type == connector->connector_type &&
       connector->connection == DRM_MODE_CONNECTED)
      found_conn = 1;
    else{
      drmModeFreeConnector(connector);
      connector = NULL;
      continue;
    }
    mode = &connector->modes[0];
    fprintf(stderr,"<<<<< To find connector_id = %u,connector_type = %d connection = %d,mode w=%d,h=%d\n",
            connector->connector_id,connector->connector_type,connector->connection,mode->hdisplay,mode->vdisplay);

    if (found_conn){
      fprintf(stderr, ">>>>> Find active connect_id %d\n", connector->connector_id);
      break;
    }
    drmModeFreeConnector(connector);
    connector = NULL;
    mode = NULL;
  }

  if (!found_conn) {
    fprintf(stderr, "failed to find connected connect\n");
    return -ENODEV;
  }

  int found_encoder = 0;
  for (int i = 0; i < res->count_encoders; ++i) {
    encoder = drmModeGetEncoder(fd, res->encoders[i]);
    if (!encoder) {
      fprintf(stderr, "Failed to get encoder %d", encoder->encoder_id);
    }
    if(encoder->encoder_id == connector->encoders[0]){
       found_encoder = 1;
       fprintf(stderr, ">>>>> Find encoder %d , connector_id = %d \n", encoder->encoder_id,connector->connector_id);
       break;
    }
    drmModeFreeEncoder(encoder);
    encoder = NULL;
  }

  if(!found_encoder){
    fprintf(stderr, "failed to find connect_id = %d encoder\n",connector->connector_id);
    return -ENODEV;
  }

  for (int k = 0; k < res->count_crtcs; ++k) {
    crtc = drmModeGetCrtc(fd, res->crtcs[k]);
    if (!crtc) {
      fprintf(stderr, "Could not get crtc %u: %s\n",
          res->crtcs[k], strerror(errno));
      continue;
    }
    if((1 << k) & encoder->possible_crtcs){
      fprintf(stderr,"<<<<< To find active connector = %d,crtc_id = %d, encoder = %d\n",connector->connector_id,crtc->crtc_id,encoder->encoder_id);
      /* enable crtc and connect */
      ret = drmModeSetCrtc(fd, crtc->crtc_id, fb_id, 0, 0, &(connector->connector_id), 1, mode);
      if (ret) {
        fprintf(stderr, "drmModeSetCrtc faild:%d\n", ret);
        found_crtc = 0;
      }else{
        found_crtc = k+1;
      }
    }
    if (found_crtc){
      fprintf(stderr, ">>>>> Find active crtc %d\n", crtc->crtc_id);
      return 0;
    }
    drmModeFreeCrtc(crtc);
    crtc = NULL;
  }

  if(!found_crtc){
    fprintf(stderr, "Failed to find crtc by connected connector\n", crtc->crtc_id);
    drmModeFreeConnector(connector);
    drmModeFreeEncoder(encoder);
    connector = NULL;
    encoder = NULL;
    mode = NULL;
  }

  return -ENODEV;

}

int find_available_win(struct win_arg win_args){
  plane_res = drmModeGetPlaneResources(fd);
  for(uint32_t i = 0; i < plane_res->count_planes; i++){
    plane = drmModeGetPlane(fd, plane_res->planes[i]);
    if (!plane) {
      fprintf(stderr, "Failed to found plane[%d] %s\n",plane->plane_id, strerror(errno));
      drmModeFreePlaneResources(plane_res);
      plane_res = NULL;
      return -ENODEV;
    }

    props = drmModeObjectGetProperties(fd, plane->plane_id,DRM_MODE_OBJECT_PLANE);
    if (!props) {
      fprintf(stderr, "Failed to found props plane[%d] %s\n",plane->plane_id, strerror(errno));
      drmModeFreePlane(plane);
      drmModeFreePlaneResources(plane_res);
      plane = NULL;
      plane_res = NULL;
      return -ENODEV;
    }
    //fprintf(stderr, "\t Index = %2u, found_crtc = %d ,possible_crtcs = %d \n", i, found_crtc, plane->possible_crtcs);
    if (plane->possible_crtcs == found_crtc) {
    }else{
      drmModeFreePlane(plane);
      plane = NULL;
      continue;
    }
    for (uint32_t j = 0; j < props->count_props; j++) {
      prop = drmModeGetProperty(fd, props->props[j]);
      //fprintf(stderr,"\t Index = %2u, prop_name = %15s, value = %lu \n", j, prop->name, props->prop_values[j]);
      if(!strcmp(prop->name, "type")){
        fprintf(stderr,"<<<<< Check plane = %d type = %x, acquire win-type = %x perf = %d\n",plane->plane_id, \
                  props->prop_values[j], win_args.win_type & 0x3, (win_args.win_type & DRM_PLANE_PERFORMANCE) > 0);
        switch(win_args.win_type){
          case DRM_PLANE_TYPE_PRIMARY | DRM_PLANE_PERFORMANCE:
            if (props->prop_values[j] == DRM_PLANE_TYPE_PRIMARY) {
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  found_plane++;
                }
              }
            }
            break;
         case DRM_PLANE_TYPE_PRIMARY:
            if (props->prop_values[j] == DRM_PLANE_TYPE_PRIMARY) {
              bool isPerformance = false;
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  isPerformance = true;
                }
              }
              if(!isPerformance)
                found_plane++;
            }
            break;
          case DRM_PLANE_TYPE_OVERLAY | DRM_PLANE_PERFORMANCE:
            if (props->prop_values[j] == DRM_PLANE_TYPE_OVERLAY) {
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  found_plane++;
                }
              }
            }
            break;
          case DRM_PLANE_TYPE_OVERLAY:
            if (props->prop_values[j] == DRM_PLANE_TYPE_OVERLAY) {
              bool isPerformance = false;
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  isPerformance = true;
                }
              }
              if(!isPerformance)
                found_plane++;
            }
            break;
          case DRM_PLANE_TYPE_CURSOR | DRM_PLANE_PERFORMANCE:
            if (props->prop_values[j] == DRM_PLANE_TYPE_CURSOR) {
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  found_plane++;
                }
              }
            }
            break;
          case DRM_PLANE_TYPE_CURSOR:
            if (props->prop_values[j] == DRM_PLANE_TYPE_CURSOR) {
              bool isPerformance = false;
              for (uint32_t j = 0; j < plane->count_formats; j++) {
                if (plane->formats[j] == DRM_FORMAT_NV12 ||
                    plane->formats[j] == DRM_FORMAT_NV21) {
                  isPerformance = true;
                }
              }
              if(!isPerformance)
                found_plane++;
            }
            break;
          default:
            fprintf(stderr,"Invalid win-type = %x",win_args.win_type);
            break;

        }
      }
      drmModeFreeProperty(prop);
      prop = NULL;
    }
    if(found_plane){
        fprintf(stderr,">>>>> Find active plane_id = %2d \n", plane->plane_id);
        break;
    }
    drmModeFreeObjectProperties(props);
    drmModeFreePlane(plane);
    props = NULL;
    plane = NULL;
  }

  if(!found_plane){
    fprintf(stderr,">>>>> Fail to find active plane\n");
    drmModeFreePlaneResources(plane_res);
    plane_res = NULL;
    return -1;
  }

  for (uint32_t i = 0; i < props->count_props; i++) {
    prop = drmModeGetProperty(fd, props->props[i]);
    if (!strcmp(prop->name, "CRTC_ID"))
      plane_prop.crtc_id = prop->prop_id;
    else if (!strcmp(prop->name, "FB_ID"))
      plane_prop.fb_id = prop->prop_id;
    else if (!strcmp(prop->name, "SRC_X"))
      plane_prop.src_x = prop->prop_id;
    else if (!strcmp(prop->name, "SRC_Y"))
      plane_prop.src_y = prop->prop_id;
    else if (!strcmp(prop->name, "SRC_W"))
      plane_prop.src_w = prop->prop_id;
    else if (!strcmp(prop->name, "SRC_H"))
      plane_prop.src_h = prop->prop_id;
    else if (!strcmp(prop->name, "CRTC_X"))
      plane_prop.crtc_x = prop->prop_id;
    else if (!strcmp(prop->name, "CRTC_Y"))
      plane_prop.crtc_y = prop->prop_id;
    else if (!strcmp(prop->name, "CRTC_W"))
      plane_prop.crtc_w = prop->prop_id;
    else if (!strcmp(prop->name, "CRTC_H"))
      plane_prop.crtc_h = prop->prop_id;
    else if (!strcmp(prop->name, "ZPOS")) {
      plane_prop.zpos = prop->prop_id;
    } else
      continue;
  }
  return 0;
}



int vop_init(struct win_arg win_args,uint32_t fb_id){


  fd = drmOpen("rockchip", NULL);
  if (fd < 0) {
    fprintf(stderr, "failed to open rockchip drm: %s\n",
      strerror(errno));
    return fd;
  }

  ret = drmSetClientCap(fd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1);
  if (ret) {
    fprintf(stderr, "Failed to set atomic cap %s", strerror(errno));
    return ret;
  }

  ret = drmSetClientCap(fd, DRM_CLIENT_CAP_ATOMIC, 1);
  if (ret) {
    fprintf(stderr, "Failed to set atomic cap %s", strerror(errno));
    return ret;
  }

  res = drmModeGetResources(fd);
  if (!res) {
    fprintf(stderr, "Failed to get resources: %s\n",
      strerror(errno));
    return -ENODEV;
  }

  //Find a usable crtc
  if(win_args.connector_type != 0){
    ret = find_active_crtc_by_connector_type(win_args);
    if(ret < 0){
      fprintf(stderr, "vop_init can't find dst active connector,type = %d \n",win_args.connector_type);
    }
  }

  if(win_args.connector_type != 0 && ret < 0){
    ret = find_crtc_by_connector_type(win_args,fb_id);
    if(ret < 0){
      fprintf(stderr, "vop_init can't find crtc by connector_type = %d ! \n",win_args.connector_type);
    }
  }

  if(ret < 0 && win_args.crtc_id != 0){
    ret = find_crtc_by_crtc_id(win_args,fb_id);
    if(ret < 0){
      fprintf(stderr, "vop_init can't find crtc by crtc_id = %d ! \n",win_args.crtc_id);
    }
  }

  if(ret < 0){
    ret = find_active_crtc(win_args);
    if(ret < 0){
      fprintf(stderr, "vop_init can't find any active crtc! init err! \n");
      return ret;
    }
  }

  //Find available win
  ret = find_available_win(win_args);
  return ret;

}

int vop_set(struct win_arg win_args,uint32_t fb_id){

  uint32_t flags = 0;
  drmModeAtomicReq *req = drmModeAtomicAlloc();

  //fprintf(stderr,">>>>> To commit: \n");

  DRM_ATOMIC_ADD_PROP(plane->plane_id, "crtc-id", plane_prop.crtc_id, crtc->crtc_id);           //crtc_id
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  fb-id", plane_prop.fb_id, fb_id);                     //src fd
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  src-x", plane_prop.src_x, win_args.crop_left << 16);        //src xoffset
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  src-y", plane_prop.src_y, win_args.crop_top << 16);         //src yoffset
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  src-W", plane_prop.src_w, win_args.crop_w << 16);     //src Width
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  src-H", plane_prop.src_h, win_args.crop_h << 16);     //src Height
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  dst-x", plane_prop.crtc_x, win_args.disp_left);       //dst xoffset
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  dst-y", plane_prop.crtc_y, win_args.disp_top);        //dst yoffset
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  dst-W", plane_prop.crtc_w, win_args.disp_w);          //dst Width
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "  dst-H", plane_prop.crtc_h, win_args.disp_h);          //dst Height
  DRM_ATOMIC_ADD_PROP(plane->plane_id, "   zpos", plane_prop.zpos, win_args.zpos);              //zpos
  //flags |= DRM_MODE_ATOMIC_ALLOW_MODESET;
  ret = drmModeAtomicCommit(fd, req, flags, NULL);
  if (ret)
    fprintf(stderr, "atomic: couldn't commit new state: %s\n", strerror(errno));

  drmModeAtomicFree(req);
  return ret;
}

int vop_disable(struct win_arg win_args){

  drmModeAtomicReqPtr pset = drmModeAtomicAlloc();
  if (!pset) {
    fprintf(stderr,"Failed to allocate property set");
    return -ENOMEM;
  }

  int ret;
  for (uint32_t j = 0; j < props->count_props; j++) {
    prop = drmModeGetProperty(fd, props->props[j]);
    //fprintf(stderr,"\t Index = %2u, prop_name = %15s, value = %lu \n", j, prop->name, props->prop_values[j]);
    if (!strcmp(prop->name, "CRTC_ID")) {
      ret = drmModeAtomicAddProperty(pset, plane->plane_id, prop->prop_id,0) < 0;
      if (ret) {
        fprintf(stderr,"Failed to add plane %d disable to pset", plane->plane_id);
        drmModeAtomicFree(pset);
        return ret;
      }
    }
    if (!strcmp(prop->name, "FB_ID")) {
      ret = drmModeAtomicAddProperty(pset, plane->plane_id, prop->prop_id,0) < 0;
      if (ret) {
        fprintf(stderr,"Failed to add plane %d disable to pset", plane->plane_id);
        drmModeAtomicFree(pset);
        return ret;
      }
    }
  }

  uint32_t flags = DRM_MODE_ATOMIC_ALLOW_MODESET;
  ret = drmModeAtomicCommit(fd, pset, flags, NULL);
  if (ret) {
    fprintf(stderr,"Failed to commit pset ret=%d\n", ret);
    drmModeAtomicFree(pset);
    return ret;
  }

  drmModeAtomicFree(pset);

  return 0;
}


int vop_uninit(){
  if(fd > 0)
    drmClose(fd);
  if(res)
    drmModeFreeResources(res);
  if(connector)
    drmModeFreeConnector(connector);
  if(crtc)
    drmModeFreeCrtc(crtc);
  if(plane_res)
    drmModeFreePlaneResources(plane_res);
  if(plane)
    drmModeFreePlane(plane);
  if(props)
    drmModeFreeObjectProperties(props);
  if(prop)
    drmModeFreeProperty(prop);

  return 0;
}


